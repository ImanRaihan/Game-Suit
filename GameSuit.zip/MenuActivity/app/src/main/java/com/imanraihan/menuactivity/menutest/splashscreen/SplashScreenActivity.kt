package com.imanraihan.menuactivity.menutest.splashscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.WindowManager
import com.bumptech.glide.Glide
import com.imanraihan.menuactivity.R
import com.imanraihan.menuactivity.databinding.ActivitySplashScreenBinding
import com.imanraihan.menuactivity.menutest.onboarding.OnBoardingActivity

@Suppress("DEPRECATION")
class SplashScreenActivity : AppCompatActivity() {

    private val binding : ActivitySplashScreenBinding by lazy {
        ActivitySplashScreenBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val media = "https://i.ibb.co/HC5ZPgD/splash-screen1.png"
        if (media !== null) {
            Glide.with(this)
                .load(media)
                .into(binding.logoGame)
        } else {
            binding.logoGame.setImageResource(R.drawable.splash_screen1)
        }

        supportActionBar?.hide()

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        Handler().postDelayed({
            val intent = Intent(this, OnBoardingActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        }, 3000)
    }
}