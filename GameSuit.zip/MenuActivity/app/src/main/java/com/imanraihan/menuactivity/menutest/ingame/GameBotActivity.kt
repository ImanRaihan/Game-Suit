package com.imanraihan.menuactivity.menutest.ingame

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.view.isVisible
import com.google.android.material.snackbar.Snackbar
import com.imanraihan.menuactivity.databinding.ActivityGameBotBinding
import com.imanraihan.menuactivity.menutest.menupage.MenuPage
import com.imanraihan.menuactivity.menutest.onboarding.EditTextFragment

@Suppress("UNREACHABLE_CODE")
class GameBotActivity : AppCompatActivity() {
     private val binding : ActivityGameBotBinding by lazy {
         ActivityGameBotBinding.inflate(layoutInflater)
     }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        unmuteBotton()

        binding.bttnBatuPlayer.setOnClickListener {
            gameBot(player = "Batu", computer = "Batu")
            muteBotton()
        }
        binding.bttnGuntingPlayer.setOnClickListener {
            gameBot(player = "Gunting", computer = "Gunting")
            muteBotton()
        }
        binding.bttnKertasPlayer.setOnClickListener {
            gameBot(player = "Kertas", computer = "Kertas")
            muteBotton()
        }
        binding.bttnReset.setOnClickListener {
            resetGame()
        }
    }

    @Suppress("NAME_SHADOWING")
    private fun gameBot(player: String, computer: String): String {

        val player: String = listOf<String>("Batu", "Gunting", "Kertas").toString()
        val pilihan: String = listOf<String>("Batu", "Gunting", "Kertas").random()
        val computer: String = pilihan

        return if (player == computer) {
            "DRAW !!"
        } else (if (player == "Batu" && computer == "Kertas") {
            "Computer Win !"
        } else if (player == "Kertas" && computer == "Gunting") {
            "Computer Win !"
        } else if (player == "Gunting" && computer == "Batu") {
            "Computer Win !"
        } else if (player == "Batu" && computer == "Kertas") {
            "Player 1 Win !!!"
        } else if (player == "Gunting" && computer == "Kertas") {
           "Player 1 Win !!!"
        } else if (player == "Kertas" && computer == "Batu") {
            "Player 1 Win !!!"
        } else "ERROR 404 :(" )

        val hasil = gameBot(player, bot().toString())
        val iintent = Intent(this, EditTextFragment::class.java)

        Log.d("debuggingJanKenPon!!!", "Input Player 1: " + player)
        Log.d("debuggingJanKenPon!!!", "Input Computer: " + computer)
        Log.d("debuggingJanKenPon!!!", "Hasil Akhir: " + hasil)

        return hasil
        AlertDialog.Builder(this).apply {
            setTitle("Hasil Permainan")
            setMessage(hasil)
            setPositiveButton("Ganti Nama?") { dialog, id ->
                startActivity(iintent)
            }
            setNegativeButton("Lihat Page") { dialog, id ->
            }

        }.create().show().toString()

        Toast.makeText(this, hasil, Toast.LENGTH_SHORT).show()
    }

    private fun bot() {
        val pilihan: String = listOf<String>("Batu", "Gunting", "Kertas").random()
        val computer: String = pilihan
    }

    private fun resetGame() {
        binding.bttnReset.setOnClickListener {
            val intent = Intent(this, MenuPage::class.java)
            startActivity(intent)
        }
    }

        private fun muteBotton() {
            binding.bttnGuntingPlayer.isEnabled = false
            binding.bttnBatuPlayer.isEnabled = false
            binding.bttnKertasPlayer.isEnabled = false
        }

        private fun unmuteBotton() {
            binding.bttnGuntingPlayer.isEnabled = true
            binding.bttnBatuPlayer.isEnabled = true
            binding.bttnKertasPlayer.isEnabled = true
        }
}