package com.imanraihan.menuactivity.menutest.menupage

import android.app.PendingIntent.getActivity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.imanraihan.menuactivity.R
import com.imanraihan.menuactivity.databinding.PageMenuBinding
import com.imanraihan.menuactivity.menutest.ingame.GameBotActivity
import com.imanraihan.menuactivity.menutest.ingame.InGameActivity

class MenuPage : AppCompatActivity() {

    private val binding : PageMenuBinding by lazy {
        PageMenuBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.imgCom.setOnClickListener {
            val iintent = Intent(this, GameBotActivity::class.java)
            startActivity(iintent)
        }

        binding.imgPlayer.setOnClickListener {
            val iiintent = Intent(this, InGameActivity::class.java)
            startActivity(iiintent)
        }

        val name = intent.getStringExtra("name_extra")

        binding.hiName.text = "Hi " + name.toString()

        val snackBar = Snackbar.make(binding.root, "Welcome to da Party $name !!", Snackbar.LENGTH_INDEFINITE)
        snackBar.setAction("Tutup") {
            snackBar.dismiss()
        }
        snackBar.show()
    }

    companion object{
        const val NAME_EXTRA ="name_extra"
    }
}