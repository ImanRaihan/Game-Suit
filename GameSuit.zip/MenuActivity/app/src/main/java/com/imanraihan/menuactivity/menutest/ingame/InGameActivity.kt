package com.imanraihan.menuactivity.menutest.ingame

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.view.isVisible
import com.imanraihan.menuactivity.databinding.ActivityInGameBinding
import com.imanraihan.menuactivity.menutest.menupage.MenuPage
import com.imanraihan.menuactivity.menutest.onboarding.EditTextFragment


class InGameActivity : AppCompatActivity() {

    private val binding: ActivityInGameBinding by lazy {
        ActivityInGameBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        AlertDialog.Builder(this).apply {
            setTitle("Hasil Permainan")
            setMessage("ppp")
            setPositiveButton("Main lagi") { dialog, id ->
                startActivity(intent)
            }
            setNegativeButton("Lihat Page") { dialog, id ->
            }

        }.create().show()

        binding.btnBatuPlayer.setOnClickListener {
            gamePlayer(player1 = "Batu", player2 = "")
            muteBotton()
        }
        binding.btnKertasPlayer.setOnClickListener {
            gamePlayer(player1 = "Kertas", player2 = "")
            muteBotton()
        }
        binding.btnGuntingPlayer.setOnClickListener {
            gamePlayer(player1 = "Gunting", player2 = "")
            muteBotton()
        }
        binding.btnBatuBot.setOnClickListener {
            gamePlayer(player1 = "", player2 = "Batu")
        }
        binding.btnGuntingBot.setOnClickListener {
            gamePlayer(player1 = "", player2 = "Gunting")
        }
        binding.btnKertasBot.setOnClickListener {
            gamePlayer(player1 = "", player2 = "Kertas")
        }
        binding.btnReset.setOnClickListener {
            resetGame()
        }
    }

//        binding.btnBatuPlayer.setOnClickListener {
//            gameBot(player = "Batu", computer = "Batu")
//            muteBotton()
//        }
//        binding.btnGuntingPlayer.setOnClickListener {
//            gameBot(player = "Gunting", computer = "Gunting")
//            muteBotton()
//        }
//        binding.btnKertasPlayer.setOnClickListener {
//            gameBot(player = "Kertas", computer = "Kertas")
//            muteBotton()
//        }
//        binding.btnReset.setOnClickListener {
//            resetGame()
//        }
//    }
//
//    private fun gameBot(player: String, computer: String): String {
//        return if (player == computer) {
//            "DRAW !!"
//        } else if (player == "Batu" && computer == "Kertas") {
//            "Computer Win !"
//        } else if (player == "Kertas" && computer == "Gunting") {
//            "Computer Win !"
//        } else if (player == "Gunting" && computer == "Batu") {
//            "Computer Win !"
//        } else if (player == "Batu" && computer == "Kertas") {
//            "Player 1 Win !!!"
//        } else if (player == "Gunting" && computer == "Kertas") {
//            "Player 1 Win !!!"
//        } else if (player == "Kertas" && computer == "Batu") {
//            "Player 1 Win !!!"
//        } else "ERROR 404 :("
//
//        var hasil = gameBot(player, bot().toString())
//
//        Log.d("debuggingJanKenPon!!!", "Input Player 1: " + player)
//        Log.d("debuggingJanKenPon!!!", "Input Computer: " + computer)
//        Log.d("debuggingJanKenPon!!!", "Hasil Akhir: " + hasil)
//
//        return hasil
//
//        binding.tandaPermainan.setText(hasil)
//    }
//
//    private fun bot() {
//        val pilihan: String = listOf<String>("Batu", "Gunting", "Kertas").random()
//        val computer: String = pilihan
//
//    }

        @Suppress("UNREACHABLE_CODE")
        private fun gamePlayer(player1 : String, player2: String): String {

            val player1: String = listOf<String>("Batu", "Gunting", "Kertas").toString()
            val player2: String = listOf<String>("Batu", "Gunting", "Kertas").toString()

            return if (player1 == player2) {
                "Hasil Seri!!"
            } else if (player1 == "Batu" && player2 == "Kertas") {
                "Computer Win !"
            } else if (player1 == "Kertas" && player2 == "Gunting") {
                "Computer Win !"
            } else if (player1 == "Gunting" && player2 == "Batu") {
                "Computer Win !"
            } else if (player1 == "Batu" && player2 == "Kertas") {
                "Player 1 Win !!!"
            } else if (player1 == "Gunting" && player2 == "Kertas") {
                "Player 1 Win !!!"
            } else if (player1 == "Kertas" && player2 == "Batu") {
                "Player 1 Win !!!"
            } else "ERROR 404 :("

            val hasil = gamePlayer(player1, player2.toString())
            val iintent = Intent(this, EditTextFragment::class.java)

            return hasil
            AlertDialog.Builder(this).apply {
                setTitle("Hasil Permainan")
                setMessage(hasil)
                setPositiveButton("Ganti Nama?") { dialog, id ->
                    startActivity(iintent)
                }
                setNegativeButton("Lihat Page") { dialog, id ->
                }

            }.create().show().toString()
        }

    private fun resetGame() {
        binding.btnReset.setOnClickListener {
            val intent = Intent(this, MenuPage::class.java)
            startActivity(intent)
        }
    }

    private fun muteBotton() {
        binding.btnGuntingPlayer.isEnabled = false
        binding.btnGuntingPlayer.isVisible = false
        binding.btnBatuPlayer.isEnabled = false
        binding.btnBatuPlayer.isVisible = false
        binding.btnKertasPlayer.isEnabled = false
        binding.btnKertasPlayer.isVisible = false
    }

    private fun unmuteBotton() {
        binding.btnGuntingPlayer.isEnabled = true
        binding.btnGuntingPlayer.isVisible = true
        binding.btnBatuPlayer.isEnabled = true
        binding.btnBatuPlayer.isVisible = true
        binding.btnKertasPlayer.isEnabled = true
        binding.btnKertasPlayer.isVisible = true
    }

//    private fun setPlayerBot(): String {
//        val gamePlayer() : String
//        val gameBot() : String
//
//        if (gamePlayer)
//    }
}