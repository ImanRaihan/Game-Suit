package com.imanraihan.menuactivity.menutest.onboarding

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import com.imanraihan.menuactivity.R
import com.imanraihan.menuactivity.databinding.FragmentMenuBinding
import com.imanraihan.menuactivity.menutest.menupage.MenuPage


class EditTextFragment : Fragment(), OnFinishNavigateListener{

    private lateinit var binding : FragmentMenuBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentMenuBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onFinishNavigateListener() {
        val name = binding.etName.text.toString().trim()
        if (name.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Please input your name First!!!", Toast.LENGTH_SHORT).show()
        } else {
            navigateToMenu(name)
        }
    }

    private fun navigateToMenu(name: String) {

        val name = binding.etName.editableText.toString().trim()
        val intent = Intent(requireContext(), MenuPage::class.java)

        intent.putExtra("name_extra", name)
        startActivity(intent)
    }
}
