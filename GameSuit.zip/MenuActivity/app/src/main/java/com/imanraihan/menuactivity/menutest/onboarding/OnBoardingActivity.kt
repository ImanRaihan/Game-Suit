package com.imanraihan.menuactivity.menutest.onboarding

import android.os.Bundle
import android.util.Size
import androidx.fragment.app.Fragment
import com.github.appintro.AppIntro2
import com.github.appintro.AppIntroCustomLayoutFragment
import com.github.appintro.AppIntroFragment
import com.imanraihan.menuactivity.R

class OnBoardingActivity : AppIntro2() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupSliderFragment()
    }

    override fun onDonePressed(currentFragment: Fragment?) {
        super.onDonePressed(currentFragment)
        if (currentFragment is OnFinishNavigateListener)
            currentFragment.onFinishNavigateListener()
    }

    private fun setupSliderFragment () {
        isSkipButtonEnabled = false

        addSlide(AppIntroCustomLayoutFragment.newInstance(R.layout.landing_page1))
        addSlide(AppIntroCustomLayoutFragment.newInstance(R.layout.landing_page2))
        addSlide(EditTextFragment())
    }
}

interface OnFinishNavigateListener {
    fun onFinishNavigateListener()
}
